from animal import animal

class karnivora(animal):
    def __init__(self, name, makanan, hidup, berkembang_biak, bernafas, taring):
        super().__init__(name, makanan, hidup, berkembang_biak)
        self.bernafas = bernafas
        self.taring = taring
    
    def info_karnivora(self):
        super().info_animal(),
        print("bernafas \t\t\t : ", self.bernafas)
        print("taring \t\t\t : ", self.taring)

karnivora = karnivora("singa", "daging", "alam", "melahirkan", "paru-paru", "tajam")
karnivora.info_karnivora()
