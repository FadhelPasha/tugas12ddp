class animal ():
    def __init__(self, name, makanan, hidup, berkembang_biak):
        self.name = name
        self.makanan = makanan 
        self.hidup = hidup 
        self.berkembang_biak = berkembang_biak 

    def info_animal(self):
            print (f"Nama Hewan \t\t\t:" , self.name)
            print (f"Nama Makanan \t\t\t:" , self.makanan)
            print (f"Hidup Di \t\t\t:" , self.hidup)
            print (f"Berkembang Biak \t\t:" , self.berkembang_biak)




    