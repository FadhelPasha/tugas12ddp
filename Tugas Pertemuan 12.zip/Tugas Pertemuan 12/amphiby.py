from animal import animal

class amphiby(animal):
    def __init__(self, name, makanan, hidup, berkembang_biak, jenis_air, bernafas):
        super().__init__(name, makanan, hidup, berkembang_biak)
        self.jenis_air = jenis_air
        self.bernafas = bernafas
    
    def info_amphiby(self):
        super().info_animal(),
        print("jenis air \t\t\t : ", self.jenis_air)
        print("bernafas \t\t\t : ", self.bernafas)

amphiby = amphiby("katak", "serangga", "alam", "bertelur", "air tawar", "kulit dan paru-paru")
amphiby.info_amphiby()
